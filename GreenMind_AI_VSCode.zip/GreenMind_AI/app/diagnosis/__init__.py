"""Plant disease inference services."""
