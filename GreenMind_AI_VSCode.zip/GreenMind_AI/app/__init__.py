"""GreenMind AI application package."""
